#**Here Is My Memory(H.I.M.M.)**
======================
Here Is My Memory(이하 HIMM)은 하이브리드 앱입니다.

사진에 기록을 남기고 위치를 파악할 수 있습니다.

##*업데이트 히스토리*
======================
1. 2012년 10월 18일 - 아이디어 구상 : 박창주
2. 2012년 10월 22일 - 팀 구성 : 전원
3. 2012년 10월 26일 - 아이디어 추가 : 전원
4. 2012년 10월 26일 - HIMM 구성 회의 : 전원
5. 2012년 10월 27일 - HIMM 데모 작성 : 박창주

##*맡은 파트*
======================
- 남중민 (dbflgks0602@gmail.com)- [폰갭](http://phonegap.com)
- 박창주 (pcjpcj2@gmail.com) - [포토스와이프](http://www.photoswipe.com/)
- 장형주 (dacapolife87@gmail.com) - [구글맵](http://code.google.com/p/jquery-ui-map/)
