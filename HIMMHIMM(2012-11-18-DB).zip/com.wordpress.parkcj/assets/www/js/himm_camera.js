var pictureSource;   // picture source
var destinationType; // sets the format of returned value 
var photoid= window.localStorage.getItem('photoid');
var photoData= null;
var db;
function onInit(){
	// 처음 일자
	var odate = new Date();
	var omonth = parseInt(odate.getMonth())+1;
	var today_date = odate.getFullYear()+"년 "+omonth+"월 "+odate.getDate()+"일 오늘";
	$('span#datenow').html(today_date);
	// 폰갭 기능 이벤트 리스너
	document.addEventListener("deviceready",phoneReady,false);
}

function phoneReady() {
	// 카메라
	pictureSource=navigator.camera.PictureSourceType;
    destinationType=navigator.camera.DestinationType;
    db = window.openDatabase("HIMM_DB", "1.0", "Here Is My Memory DB", 200000); 	
    createDB();
}

//Capture Start
$('#newpic').live("click",function(event){
	alert("카메라");
	event.preventDefault();
	navigator.camera.getPicture(onPhotoFileSuccess, onFail, {
		quality: 50,
		destinationType: Camera.DestinationType.FILE_URI });
});
	
$('#oldpic').live("click",function(){
	alert("갤러리");
	event.preventDefault();
    navigator.camera.getPicture(onPhotoURISuccess, onFail, 
        { quality: 50, 
          destinationType: destinationType.FILE_URI,
          sourceType: pictureSource.SAVEDPHOTOALBUM });
});

// Use Camera
function onPhotoFileSuccess(imageData) {
    var cameraImage = document.getElementById('cameraImage');
    //cameraImage.style.visibility = 'visible';
    // 2012-11-05 Unhide image Elements
    cameraImage.style.visibility = 'block';
    cameraImage.src = imageData;
    photoData = imageData;
	alert("카메라성공"+imageData);
}
//Use Gallery
function onPhotoURISuccess(imageURI) {

	var cameraImage = document.getElementById('cameraImage');
    cameraImage.src = imageURI;
    alert(cameraImage.src);
    photoData = imageURI;
	alert("갤러리 성공"+imageURI);
}

function onFail(message){
	alert('Failed because : '+message);
}
// Camera End

// DB Start

function createDB(){
    db.transaction(setupTable, dbErrorHandler, getEntries);    
}

//create table and insert some record
function setupTable(tx) {
	tx.executeSql('CREATE TABLE IF NOT EXISTS HIMM (id INTEGER PRIMARY KEY AUTOINCREMENT, Title TEXT NOT NULL, Content TEXT NOT NULL,Category INTEGER, FileURI TEXT,Longitude TEXT, Latitude TEXT)');
}

//function will be called when an error occurred
function dbErrorHandler(err) {
    alert("Error processing SQL: "+err.code);
}

//function will be called when process succeed
function getEntries() {
    db.transaction(queryDB,dbErrorHandler);
}

//select all from HIMM
function queryDB(tx){
	tx.executeSql('SELECT * FROM HIMM',[],renderList,dbErrorHandler);
	
}
var i=0;
function renderList(tx,result){
	$('#DiaryList').empty();
	$.each(result.rows,function(index){
		var row = result.rows.item(index);
		var str = "<li class='ui-li-has-thumb' id='a'><a href='#diaryContent' >";
		str +="<img class='ui-li-thumb'";
		str +="src='"+row['FileURI']+"'/>";
		str += "<h3>"+row['Title']+"</h3>";
		str += "<p class='ui-li-aside'>"+row['Category']+"</p></a></li>";
		$('#DiaryList').append(str);
		i++;
	});
	$('#DiaryList').listview("refresh");
	getCount(i);
}
function getCount(cnt){
	$('#alldata').html('<strong>'+cnt+'</strong>');
}
$("#goDiary").live("click",function(e){
	e.preventDefault();
	$.mobile.changePage("HIMM_diary.html");
});
$("#submitDiary").live("click",function(e){
	e.preventDefault();
	title = $('#diarytitle').val();
	cont = $('#diarycont').val();
	cate = $('#diarycate').val();
	fileuri =  photoData;
	long =  $('#diarylong').val();
	lat =  $('#diarylat').val();
	db.transaction(function(tx){
		tx.executeSql('INSERT INTO HIMM(Title,Content,Category,FileURI,Longitude,Latitude ) VALUES(?,?,?,?,?,?)',[title ,cont ,cate ,fileuri ,long ,lat]);
		queryDB(tx);
	});
	$('#DiaryList').listview("refresh");
	$.mobile.changePage("HIMM_diary.html");
});
$("#DiaryList li a h3").live('click',function(e){
	var idx = $(this).index();
	$('#diaryinside').html(idx);
	var str = $(this).text();
	alert(str);
	queryList(idx);
});
// queryDB ListSelected
function queryList(idx) {
	db.transaction(function(tx){
		var sql='SELECT * FROM HIMM WHERE ID = '+(idx+1);
		tx.executeSql(sql,[],renderContent,dbErrorHandler);
	});
}
function renderContent(tx,result){
	$('#diaryinside').empty();

	$.each(result.rows,function(index){
		var row = result.rows.item(index);
		var str = "<p><h1>"+row['Title']+"</h1></p>"; 
		str +="<img src='"+row['FileURI']+"' "+"style='width:300px; height:300px;'/>";
		str +="<p><em>"+row['Content']+"</em></p>";
		str +=row['Longitude'];
		str +=row['Latitude'];
		$('#diaryinside').append(str);
	});
}
// DB End