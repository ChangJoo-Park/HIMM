var pictureSource;   // picture source
var destinationType; // sets the format of returned value 
var photoid= window.localStorage.getItem('photoid');
var photoData= null;
var db;
var curlong;
var curlat;
var mapsrc;
var orgsrc;
function onInit(){
	// 처음 일자
	var odate = new Date();
	var omonth = parseInt(odate.getMonth())+1;
	var today_date = odate.getFullYear()+"년 "+omonth+"월 "+odate.getDate()+"일 오늘";
	$('span#datenow').html(today_date);
	// 폰갭 기능 이벤트 리스너
	document.addEventListener("deviceready",phoneReady,false);
}

function phoneReady() {
	// 카메라
	pictureSource=navigator.camera.PictureSourceType;
    destinationType=navigator.camera.DestinationType;
    db = window.openDatabase("HIMM_DB", "1.0", "Here Is My Memory DB", 200000); 	
    createDB();
}
// 위치 받기
function getGPS(){
	navigator.geolocation.getCurrentPosition(onSuccessGPS, onErrorGPS);
}
function onSuccessGPS(position){
	curlat = position.coords.latitude;
	curlong = position.coords.longitude;
}
function onErrorGPS(err){
	 alert('code: '    + error.code    + '\n' +'message: ' + error.message + '\n');

}
//Capture Start
$('#newpic').live("click",function(event){
	event.preventDefault();
	navigator.camera.getPicture(onPhotoFileSuccess, onFail, {
		quality: 50,
		destinationType: Camera.DestinationType.FILE_URI });
});
	
$('#oldpic').live("click",function(){
	event.preventDefault();
    navigator.camera.getPicture(onPhotoURISuccess, onFail, 
        { quality: 50, 
          destinationType: destinationType.FILE_URI,
          sourceType: pictureSource.SAVEDPHOTOALBUM });
});

// Use Camera
function onPhotoFileSuccess(imageData) {
    var cameraImage = document.getElementById('cameraImage');
    //cameraImage.style.visibility = 'visible';
    // 2012-11-05 Unhide image Elements
    cameraImage.style.visibility = 'block';
    cameraImage.src = imageData;
    photoData = imageData;
    $('#cameraImage').show();
	getGPS();
}
//Use Gallery
function onPhotoURISuccess(imageURI) {

	var cameraImage = document.getElementById('cameraImage');
    cameraImage.src = imageURI;
    photoData = imageURI;
    $('#cameraImage').show();
}

function onFail(message){
	alert('Failed because : '+message);
}
// Camera End

// DB Start

function createDB(){
    db.transaction(setupTable, dbErrorHandler, getEntries);    
}

//create table and insert some record
function setupTable(tx) {
	tx.executeSql('CREATE TABLE IF NOT EXISTS HIMM (id INTEGER PRIMARY KEY AUTOINCREMENT, Title TEXT NOT NULL, Content TEXT NOT NULL,Category INTEGER, FileURI TEXT,Longitude TEXT, Latitude TEXT,Crtime TEXT)');
}

//function will be called when an error occurred
function dbErrorHandler(err) {
    alert("Error processing SQL: "+err.code);
}

//function will be called when process succeed
function getEntries() {
    db.transaction(queryDB,dbErrorHandler);
}

//select all from HIMM
function queryDB(tx){
	tx.executeSql('SELECT * FROM HIMM ORDER BY Crtime DESC, id DESC',[],renderList,dbErrorHandler);
}
var i=0;
function renderList(tx,result){
	$('#DiaryList').empty();
	$.each(result.rows,function(index){
		var row = result.rows.item(index);
		var str = "<li class='ui-li-has-thumb' id='a'><a href='#diaryContent' >";
		str +="<img class='ui-li-thumb'";
		str +="src='"+row['FileURI']+"'/>";
		str +="<p>"+row['Crtime']+"</p>";
		str += "<h3>"+row['Title']+"</h3>";
		str += "<p class='ui-li-aside'>"+row['Category']+"</p></a></li>";
		$('#DiaryList').append(str);
		i++;
	});
	$('#DiaryList').listview("refresh");
	getCount(i);
}
function getCount(cnt){
	$('#alldata').html('<strong>'+cnt+'</strong>');
}
$("#goDiary").live("click",function(e){
	e.preventDefault();
	$.mobile.changePage("HIMM_diary.html");
});
$("#submitDiary").live("click",function(e){
	e.preventDefault();
	var crtime = $("#diarydate").val();
	var title = $('#diarytitle').val();
	var cont = $('#diarycont').val();
	var cate = $('#diarycate').val();
	var fileuri =  photoData;
	var long =  curlong;
	var lat =  curlat;
	db.transaction(function(tx){
		tx.executeSql('INSERT INTO HIMM(Title,Content,Category,FileURI,Longitude,Latitude,Crtime ) VALUES(?,?,?,?,?,?,?)',[title ,cont ,cate ,fileuri ,long ,lat, crtime]);
		queryDB(tx);
	});
	$('#DiaryList').listview("refresh");
	$.mobile.changePage("HIMM_home.html");
});
$("#DiaryList li a").live('click',function(e){
	var imgstr = $(this).find('img').attr('src');
	var titlestr = $(this).find('h3').text();
	queryList(imgstr,titlestr);
});
// 다이어리 리스트를 눌렀을때 쿼리 요청
function queryList(imgstr,titlestr) {
	db.transaction(function(tx){
		var sql='SELECT * FROM HIMM WHERE '+"FileURI = "+  "'" + imgstr + "' and"+" Title = " + "'" + titlestr + "'";
		tx.executeSql(sql,[],renderContent,dbErrorHandler);
	});
}
// 다이어리 리스트를 눌렀을때 그리는 화면
function renderContent(tx,result){
	$('#diaryinside').empty();
	$.each(result.rows,function(index){
		var row = result.rows.item(index);
		var str = "<p><h1>"+row['Title']+"</h1></p>";
		str += "<p>"+row['Crtime']+"</p>";
		str +="<img src='"+row['FileURI']+"' "+"style='width:300px; height:300px; border:5px solid #5D6F5E; padding:7px; align:center;'/>";
		str +="<p><em>"+row['Content']+"</em></p>";
		$('#diaryinside').append(str);
		curlong = row['Longitude'];
		curlat = row['Latitude'];
		orgsrc = row['FileURI'];
	});
}
// 이미지 클릭 처리
$("#diaryinside img").live("click",function(e){
	var mapsrc = "http://maps.google.com/maps/api/staticmap?center="+curlat+","+curlong+"&zoom=18&size=300x300&markers=color:red|"+curlat+","+curlong+"&sensor=false";
	if($(this).attr("src")== mapsrc){
		$(this).attr("src",orgsrc);
	}else{
		$(this).attr("src",mapsrc);
	}
});
// DB End