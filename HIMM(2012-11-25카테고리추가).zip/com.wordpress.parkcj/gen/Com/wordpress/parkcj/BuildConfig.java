/** Automatically generated file. DO NOT MODIFY */
package Com.wordpress.parkcj;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}