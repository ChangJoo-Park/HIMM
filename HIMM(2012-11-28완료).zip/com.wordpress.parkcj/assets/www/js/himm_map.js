var db;
var mapsrc;
var orgsrc;
var weather;
var today_date;
var CPos;
$(document).ready(function(){
	document.addEventListener("deviceready",phoneReady,false);
});

function phoneReady() {
    db = window.openDatabase("HIMM_DB", "1.0", "Here Is My Memory DB", 200000); 	
    navigator.geolocation.getCurrentPosition(setPos, onErrorGPS);
    getMap();
}

function onErrorGPS(err){
}
function setPos(position){
		var curPos = new Object();
		curPos.lat = position.coords.latitude;
		curPos.lng = position.coords.longitude;
		return function(){
			alert(curPoss.lat);
			alert(markers[0][0]);
		}
	}


// 맵 시작
	var markers = new Array();
function initializeMaps() {
	alert(CPos.lat);
	var myOptions = {
		mapTypeId: google.maps.MapTypeId.ROADMAP,
		mapTypeControl: false
	};
	var map = new google.maps.Map(document.getElementById("map_canvas"),myOptions);
	var infowindow = new google.maps.InfoWindow(); 
	var marker, i;
	var bounds = new google.maps.LatLngBounds();

	for (i = 0; i < markers.length; i++) { 
		var pos = new google.maps.LatLng(markers[i][1], markers[i][2]);
		bounds.extend(pos);
		marker = new google.maps.Marker({
			position: pos,
			map: map
		});
		google.maps.event.addListener(marker, 'click', (function(marker, i) {
			return function() {
				var content_s = "<h4>"+markers[i][0]+"</h4><br/>"+"<img src='"+markers[i][4]+"'"+"style='width:150px;height:150px;'/><br/><h5>"+markers[i][3]+"</h5><br/>";
				infowindow.setContent(content_s);
				infowindow.open(map, marker);
			};
		})(marker, i));
	}
	map.fitBounds(bounds);
}
function getMap() {
    db.transaction(queryMap,dbErrorHandler);
}
function dbErrorHandler(){

}

function queryMap(tx){
	tx.executeSql('SELECT * FROM HIMM',[],renderMap,dbErrorHandler);
}
function renderMap(tx,result){
		$.each(result.rows,function(index){
			var row = result.rows.item(index);
			markers[index]= new Array();
			markers[index][0] = row['Title'];
			markers[index][1] = row['Latitude'];
			markers[index][2] = row['Longitude'];
			markers[index][3] = row['Content'];
			markers[index][4] = row['FileURI'];
			markers[index][5] = row['Category'];
	});
}
