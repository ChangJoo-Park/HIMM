var pictureSource;   // picture source
var destinationType; // sets the format of returned value 
var photoid= window.localStorage.getItem('photoid');
var photoData= null;
var db;
function onInit(){
	// 처음 일자
	var odate = new Date();
	var omonth = parseInt(odate.getMonth())+1;
	var today_date = odate.getFullYear()+"년 "+omonth+"월 "+odate.getDate()+"일 오늘";
	$('span#datenow').html(today_date);
	// 폰갭 기능 이벤트 리스너
	document.addEventListener("deviceready",phoneReady,false);
}

function phoneReady() {
	// 카메라
	pictureSource=navigator.camera.PictureSourceType;
    destinationType=navigator.camera.DestinationType;
    db = window.openDatabase("HIMM_DB", "1.0", "Here Is My Memory DB", 200000); 	
    createDB();
}

//Capture Start
$('#newpic').live("click",function(event){
	event.preventDefault();
	navigator.camera.getPicture(onPhotoFileSuccess, onFail, {
		quality: 50,
		destinationType: Camera.DestinationType.FILE_URI });
});
	
$('#oldpic').live("click",function(){
	alert("갤러리");
	event.preventDefault();
    navigator.camera.getPicture(onPhotoURISuccess, onFail, 
        { quality: 50, 
          destinationType: destinationType.FILE_URI,
          sourceType: pictureSource.SAVEDPHOTOALBUM });
});

// Use Camera
function onPhotoFileSuccess(imageData) {
    var cameraImage = document.getElementById('cameraImage');
    //cameraImage.style.visibility = 'visible';
    // 2012-11-05 Unhide image Elements
    cameraImage.style.visibility = 'block';
    cameraImage.src = imageData;
    photoData = imageData;
    $('#cameraImage').show();
}
//Use Gallery
function onPhotoURISuccess(imageURI) {

	var cameraImage = document.getElementById('cameraImage');
    cameraImage.src = imageURI;
    alert(cameraImage.src);
    photoData = imageURI;
    $('#cameraImage').show();
}

function onFail(message){
	alert('Failed because : '+message);
}
// Camera End

// DB Start

function createDB(){
    db.transaction(setupTable, dbErrorHandler, getEntries);    
}

//create table and insert some record
function setupTable(tx) {
	tx.executeSql('CREATE TABLE IF NOT EXISTS HIMM (id INTEGER PRIMARY KEY AUTOINCREMENT, Title TEXT NOT NULL, Content TEXT NOT NULL,Category INTEGER, FileURI TEXT,Longitude TEXT, Latitude TEXT,Crtime TEXT)');
}

//function will be called when an error occurred
function dbErrorHandler(err) {
    alert("Error processing SQL: "+err.code);
}

//function will be called when process succeed
function getEntries() {
    db.transaction(queryDB,dbErrorHandler);
}

//select all from HIMM
function queryDB(tx){
	tx.executeSql('SELECT * FROM HIMM ORDER BY Crtime DESC, id DESC',[],renderList,dbErrorHandler);
	
}
var i=0;
function renderList(tx,result){
	$('#DiaryList').empty();
	$.each(result.rows,function(index){
		var row = result.rows.item(index);
		var str = "<li class='ui-li-has-thumb' id='a'><a href='#diaryContent' >";
		str +="<img class='ui-li-thumb'";
		str +="src='"+row['FileURI']+"'/>";
		str +="<p>"+row['Crtime']+"</p>";
		str += "<h3>"+row['Title']+"</h3>";
		str += "<p class='ui-li-aside'>"+row['Category']+"</p></a></li>";
		$('#DiaryList').append(str);
		i++;
	});
	$('#DiaryList').listview("refresh");
	getCount(i);
}
function getCount(cnt){
	$('#alldata').html('<strong>'+cnt+'</strong>');
}
$("#goDiary").live("click",function(e){
	e.preventDefault();
	$.mobile.changePage("HIMM_diary.html");
});
$("#submitDiary").live("click",function(e){
	e.preventDefault();
	crtime = $('#diarydate').val;
	title = $('#diarytitle').val();
	cont = $('#diarycont').val();
	cate = $('#diarycate').val();
	fileuri =  photoData;
	long =  $('#diarylong').val();
	lat =  $('#diarylat').val();
	db.transaction(function(tx){
		tx.executeSql('INSERT INTO HIMM(Title,Content,Category,FileURI,Longitude,Latitude,Crtime ) VALUES(?,?,?,?,?,?,?)',[title ,cont ,cate ,fileuri ,long ,lat, crtime]);
		queryDB(tx);
	});
	$('#DiaryList').listview("refresh");
	$.mobile.changePage("HIMM_diary.html");
});
$("#DiaryList li a").live('click',function(e){
	var imgstr = $(this).find('img').attr('src');
	var titlestr = $(this).find('h3').text();
	alert(imgstr);
	alert(titlestr);
	queryList(imgstr,titlestr);
});
// queryDB ListSelected
function queryList(imgstr,titlestr) {
	db.transaction(function(tx){
		var sql='SELECT * FROM HIMM WHERE '+"FileURI = "+  "'" + imgstr + "' and"+" Title = " + "'" + titlestr + "'";
		alert(sql);
		tx.executeSql(sql,[],renderContent,dbErrorHandler);
	});
}
var curmap = new Array();
function renderContent(tx,result){
	$('#diaryinside').empty();
	$.each(result.rows,function(index){
		var row = result.rows.item(index);
		var str = "<p><h1>"+row['Title']+"</h1></p>";
		str += "<p>"+row['Crtime']+"</p>";
		str +="<img src='"+row['FileURI']+"' "+"style='width:300px; height:300px; border:5px solid #5D6F5E; padding:7px; align:center;'/>";
		str +="<p><em>"+row['Content']+"</em></p>";
		curmap[0] = row['Longitude'];
		curmap[1] = row['Latitude'];
		$('#diaryinside').append(str);
		
	});
}
// 이미지 클릭 처리
$("#diaryinside img").live("click",function(e){
	alert('이미지를 누름');
	alert(curmap[0]+""+curmap[1]);
});
// DB End